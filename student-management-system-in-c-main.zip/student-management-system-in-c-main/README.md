# student-management-system-in-c
Student Information Management System In C programming language
